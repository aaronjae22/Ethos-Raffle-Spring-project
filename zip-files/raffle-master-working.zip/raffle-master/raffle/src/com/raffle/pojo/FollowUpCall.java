package com.raffle.pojo;

public class FollowUpCall {

	int idFollowUp_Call;
	String description;
	
	
	public int getIdFollowUp_Call() {
		return idFollowUp_Call;
	}
	public void setIdFollowUp_Call(int idFollowUp_Call) {
		this.idFollowUp_Call = idFollowUp_Call;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
	
}
