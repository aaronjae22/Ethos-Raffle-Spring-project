package com.raffle.pojo;

public class TicketCounterWeek
{
	private int weekNumber;
	public int getWeekNumber() {
		return weekNumber;
	}
	public void setWeekNumber(int weekNumber) {
		this.weekNumber = weekNumber;
	}
	public int getCounter() {
		return counter;
	}
	public void setCounter(int counter) {
		this.counter = counter;
	}
	private int counter;
	
	
}
