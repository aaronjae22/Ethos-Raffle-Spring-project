package com.raffle.pojo;

public class TicketNumbers {

	
	private int idTicketNumbers;
	private int idPeriod ;	
	private String ticketNumber;	
	private int idProduct;
	
	public int getIdTicketNumbers() {
		return idTicketNumbers;
	}
	public void setIdTicketNumbers(int idTicketNumbers) {
		this.idTicketNumbers = idTicketNumbers;
	}
	public int getIdPeriod() {
		return idPeriod;
	}
	public void setIdPeriod(int idPeriod) {
		this.idPeriod = idPeriod;
	}
	public String getTicketNumber() {
		return ticketNumber;
	}
	public void setTicketNumber(String ticketNumber) {
		this.ticketNumber = ticketNumber;
	}
	public int getIdProduct() {
		return idProduct;
	}
	public void setIdProduct(int idProduct) {
		this.idProduct = idProduct;
	}
}

